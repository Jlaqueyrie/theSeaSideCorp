<ul id="menu-haut">
    <li><i class="fa fa-ship" aria-hidden="true"></i><a href=index.php>Accueil</a></li>
    <li><i class="fa fa-shopping-basket" aria-hidden="true"></i><a href=produit.php>Produit</a></li>
    <li><i class="fa fa-address-book" aria-hidden="true"></i><a href=contact.php>Contact</a></li>
</ul>