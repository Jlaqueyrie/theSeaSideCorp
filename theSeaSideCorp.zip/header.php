<header>
    <img id="logo" src="images/logo.png" alt="logo de la companie">
    <?php include('menu.php')?>
</header>